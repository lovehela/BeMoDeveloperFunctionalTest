<?php if (!$kirby->user()) go('/') ?>
<?php
/**
 * Snippets are a great way to store code snippets for reuse or to keep your templates clean.
 * This header snippet is reused in all templates. 
 * It fetches information from the `site.txt` content file and contains the site navigation.
 * More about snippets: https://getkirby.com/docs/guide/templates/snippets
 */
?>

<!doctype html>
<html lang="en">
<head>
  <?= $site->google_analytics()->kt() ?>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">

  <!-- The title tag we show the title of our site and the title of the current page -->
  <title><?= $page->meta_title() ?> | <?= $site->title() ?> </title>
   <meta name="description" content= <?= $page->desc() ?>>

  <!-- Stylesheets can be included using the `css()` helper. Kirby also provides the `js()` helper to include script file. 
        More Kirby helpers: https://getkirby.com/docs/reference/templates/helpers -->
  <?= css(['assets/css/index.css', '@auto']) ?>
   <?php if($page->noindex()->bool()): ?>
    <meta name="robots" content="noindex" />
  <?php endif ?>
  <?= $site->facebook_pixel()->kt() ?>
</head>
<body>
    <!-- currently the header isn't moving downwards as I can't get sticky to work right.  -->
    <header class="header navBar">
      <!-- In this link we call `$site->url()` to create a link back to the homepage -->
      <a class="logo" href="<?= $site->url() ?>">
	<?php foreach($site->images() as $file): ?>
  	  <img class="logoImg" aria-hidden="true" src="<?= $file->url() ?>">
	<?php endforeach ?>
      </a>

      <nav id="menu" class="menu">
        <?php 
        // In the menu, we only fetch listed pages, i.e. the pages that have a prepended number in their foldername
        // We do not want to display links to unlisted `error`, `home`, or `sandbox` pages
        // More about page status: https://getkirby.com/docs/reference/panel/blueprints/page#statuses
        foreach ($site->children()->listed() as $item): ?>
        <?= $item->title()->link() ?>
        <?php endforeach ?>
      </nav>
    </header>
