<?php
/**
 * Snippets are a great way to store code snippets for reuse or to keep your templates clean.
 * in loops or simply to keep your templates clean.
 * This footer snippet is reused in all templates. In fetches information from the `site.txt` content file
 * and from the `about` page.
 * More about snippets: https://getkirby.com/docs/guide/templates/snippets
 */
?>

  <footer class="footer">
    <?= $site->copywright()->kt() ?>
    <nav>
     <!-- these images aren't mine, and can't be reused, just put them there to allow for the alt tag so screen readers can read the link, ideally will be changed later with prefered icons, which is why I'm styling them here -->
      <a class="socialIcons" href=https://www.facebook.com/bemoacademicconsulting><img src=https://vectorified.com/images/white-facebook-icon-transparent-background-3.png alt=facebook style="max-height:1.5em" /> </a>
      <a class="socialIcons" href=https://twitter.com/BeMo_AC> <img src=https://i.ya-webdesign.com/images/white-twitter-icon-png-15.png alt=twitter style="max-height: 1.5em" /></a>
    </nav>
  </footer>

</body>
</html>
