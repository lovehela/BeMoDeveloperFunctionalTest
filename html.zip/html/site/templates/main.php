<?php
/**
 * Templates render the content of your pages. 
 * They contain the markup together with some control structures like loops or if-statements.
 * The `$page` variable always refers to the currently active page. 
 * To fetch the content from each field we call the field name as a method on the `$page` object, e.g. `$page->title()`. 
 * This home template renders content from others pages, the children of the `photography` page to display a nice gallery grid.
 * Snippets like the header and footer contain markup used in multiple templates. They also help to keep templates clean.
 * More about templates: https://getkirby.com/docs/guide/templates/basics
 */
?>

<?php snippet('header') ?>

  <!-- This is the main title that we see on the page, I decided to make it a header and have the image of the current website as the background to it so that the image doesn't show up on screen readers. It also allows for the image to get smaller on phones so it isn't such an annoying thing to scroll through all the time. It does mean the image will be cut off since I'll make it at a minimum only 1/3 of the screen at any time -->
  <h1 class="mainTitle" id="mainTitle"> <?= $page->headline() ?> </h1> 
  <article> <?= $page->text()->kt() ?> </article>
<script>
document.addEventListener('DOMContentLoaded', (event) => {
  <?php foreach($page->images() as $image): ?>
   document.getElementById("mainTitle").style.backgroundImage = "url('<?= $image->url() ?>')";
   document.getElementById("mainTitle").style.backgroundSize = "100% 100%";
   document.getElementById("mainTitle").style.backgroundRepeat = "no-repeat";
  <?php endforeach ?>
})
</script>

<?php snippet('footer') ?>

