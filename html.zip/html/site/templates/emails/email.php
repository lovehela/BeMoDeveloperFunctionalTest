
Hi BeMo,

<?= $text ?>

<?= $sender ?>
