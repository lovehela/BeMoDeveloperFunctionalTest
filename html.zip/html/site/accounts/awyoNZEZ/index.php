<?php

return [
    'email' => 'helaina.love@mail.utoronto.ca',
    'language' => 'en',
    'name' => '',
    'role' => 'admin'
];