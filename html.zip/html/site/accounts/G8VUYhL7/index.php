<?php

return [
    'email' => 'beemo@example.com',
    'language' => 'en',
    'name' => 'bemo@example.com',
    'role' => 'admin'
];